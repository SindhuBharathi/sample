package com.revature.model;

import lombok.Data;

@Data
public class Seat {
	private int id;
	private String name;
	private boolean status;
}
